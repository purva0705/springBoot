package com.atossyntel.greet.controller;

import java.util.Date;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RequestMapping("/hello")
@RestController
public class HelloController {

	
	@GetMapping
	public String getTodaysMessage() {
		return "Hello Students Today is :"+new Date();
		}

		

	
	
}
