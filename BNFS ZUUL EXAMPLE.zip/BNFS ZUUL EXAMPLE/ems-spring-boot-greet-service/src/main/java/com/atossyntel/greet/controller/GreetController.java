package com.atossyntel.greet.controller;

import java.util.Arrays;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RequestMapping("/messages")
@RestController
public class GreetController {

	
	@GetMapping
	public List<String> getAllMessages() {
		System.out.println("In get allMEssages");
		return Arrays.asList("Hello Students!!","Hello World","Good Bye");
		}

		

	
	
}
