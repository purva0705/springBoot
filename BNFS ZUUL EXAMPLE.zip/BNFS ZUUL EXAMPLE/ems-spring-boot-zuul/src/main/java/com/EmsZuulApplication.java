package com;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.cloud.netflix.zuul.EnableZuulProxy;


@EnableZuulProxy
@SpringBootApplication
public class EmsZuulApplication {

	public EmsZuulApplication() {
		System.out.println("EmsZuulApplication   created....");
	}

	public static void main(String[] args) {
		SpringApplication.run(EmsZuulApplication.class, args);
	}
	
	

	
}
