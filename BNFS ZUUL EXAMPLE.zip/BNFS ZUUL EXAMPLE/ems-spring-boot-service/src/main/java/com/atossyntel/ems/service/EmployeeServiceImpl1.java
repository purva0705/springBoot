package com.atossyntel.ems.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.atossyntel.ems.model.Employee;
import com.atossyntel.ems.reposiotry.EmployeeJPARepository;

@Service
public class EmployeeServiceImpl1 implements EmployeeService {

	@Autowired
	private EmployeeJPARepository repository;

	public EmployeeServiceImpl1() {
		System.out.println("EmployeeServiceImpl1 created.,.....");
	}

	@Override
	public Employee findEmployee(int employeeId) {
		// TODO Auto-generated method stub
		return repository.findById(employeeId).get();
	}

	@Override
	public boolean deleteEmployee(int employeeId) {

		Employee e = repository.findById(employeeId).get();

		if (e != null) {
			repository.delete(e);
			return true;
		}

		return false;
	}

	@Override
	public boolean updateEmployee(Employee employee) {

		Employee e = repository.findById(employee.getEmployeeId()).get();

		if (e != null) {
			repository.save(employee);
			return true;
		}

		return false;
	}

	@Override
	public boolean addEmployee(Employee employee) {
		// TODO Auto-generated method stub
		return repository.save(employee) == employee;
	}

	@Override
	public List<Employee> findAllEmployees() {

		return repository.findAll();
	}

}
