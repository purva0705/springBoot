package com.atossyntel.ems.spring.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.atossyntel.ems.model.Employee;
import com.atossyntel.ems.service.EmployeeService;


@Controller
public class EmsSpringController {
	
	
	@Autowired
	private EmployeeService employeeService;

	public EmsSpringController() {
		System.out.println("EmsSpringController created...");
	}

	@RequestMapping("/semployees")
	public ModelAndView getAllEmployees(){
	return new ModelAndView("employeeList", "employees", employeeService.findAllEmployees());	
	}
	
	
	@RequestMapping("/semployees/edit/{id}")
	public String editEmployee(@PathVariable("id") int employeeId,ModelMap map){
		System.out.println("In editemployee "+employeeId);
		
		map.addAttribute("employee",employeeService.findEmployee(employeeId));
		map.addAttribute("employees",employeeService.findAllEmployees());
			
	return  "editEmployee";
			
	}
	
	
	@RequestMapping("/semployees/delete")
	public String deleteEmployee(@RequestParam("employeeId") int employeeId,ModelMap map){
	
		System.out.println("In deleteemployee "+employeeId);
		
		
		employeeService.deleteEmployee(employeeId);
	
		map.addAttribute("employees",employeeService.findAllEmployees());
		
		
	     return  "employeeList";
			
	}
	
	
	@RequestMapping("/semployees/new")
	public String newEmployee(ModelMap map){
	
		map.addAttribute("employee",new Employee());
		map.addAttribute("employees",employeeService.findAllEmployees());
	
	   return  "addEmployee";
			
	}
	
	
	@RequestMapping(value="/semployees/add",method=RequestMethod.POST)
	public String addEmployee(Employee employee,ModelMap map){
	
		employeeService.addEmployee(employee);
		
		map.addAttribute("employees",employeeService.findAllEmployees());
	
	   return  "employeeList";
			
	}
	
	
	@RequestMapping(value="/semployees/update",method=RequestMethod.POST)
	
	public String updateEmployee(Employee employee,ModelMap map){
	
		employeeService.updateEmployee(employee);
		
		map.addAttribute("employees",employeeService.findAllEmployees());
	
	   return  "employeeList";
			
	}
	
	

}
