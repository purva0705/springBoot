package com.atossyntel.ems.rest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.ContextLoaderListener;
import org.springframework.web.servlet.ModelAndView;

import com.atossyntel.ems.model.Employee;
import com.atossyntel.ems.service.EmployeeService;

@RequestMapping("/employees")
@RestController
public class EmsRestController {

	
	@Autowired
	private EmployeeService employeeService;

	public EmsRestController() {
		System.out.println("EmsRestController created...");
	}

	@GetMapping
	public List<Employee> getAllEmployees() {
		System.out.println("In get allEmployeess");
		return employeeService.findAllEmployees();
	}

	@GetMapping("/{employeeId}")
	public Employee getEmployee(@PathVariable("employeeId") int employeeId) {
		System.out.println("In get Employee " + employeeId);
		return employeeService.findEmployee(employeeId);
	}

	@DeleteMapping("/{employeeId}")
	public List<Employee> deleteEmployee(@PathVariable("employeeId") int employeeId) {
		System.out.println("In delete Employee " + employeeId);

		employeeService.deleteEmployee(employeeId);

		return employeeService.findAllEmployees();

	}

	
	@PutMapping("/{employeeId}")
	public List<Employee> updateEmployee(@PathVariable("employeeId") int employeeId,@RequestBody Employee employee) {
		System.out.println("In update Employee " + employee);

		employeeService.updateEmployee(employee);

		return employeeService.findAllEmployees();

	}
	
	
	@PostMapping
	public List<Employee> addEmployee(@RequestBody Employee employee) {
		System.out.println("In add Employee " + employee);

		employeeService.addEmployee(employee);

		return employeeService.findAllEmployees();

	}
	

	
	
}
