package com.atossyntel.ems.rest.controller;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.atossyntel.ems.model.Employee;
import com.atossyntel.ems.service.EmployeeService;

@RequestMapping("/employees")
@Controller
public class EmsRestController {

@Autowired
private EmployeeService employeeService;  //dependenecy

public EmsRestController() {
System.out.println("EmsRest Controller  Created.....");
}

@RequestMapping
public  @ResponseBody List<Employee> getAllEmployees(){
	System.out.println("EmsRest Controller  getallemployees....");
	
	return employeeService.findAllEmployees();
}


@RequestMapping("/today")
public  @ResponseBody String  today(){
	System.out.println("EmsRest Controller  today method..");

	return "Today is "+new Date();
}

}
