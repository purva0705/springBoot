package com.atossyntel.ems.data;

import java.util.HashMap;
import java.util.Map;

import com.atossyntel.ems.model.Employee;

public enum EmployeeMap {
INSTANCE;	
	
private Map<Integer, Employee>	map;

private EmployeeMap() {
this.map=new HashMap<>();
Employee e1=new Employee("pradeep", "chinchole", 233456.77565, "8149987432", "AMXPC9845T");
Employee e2=new Employee("amol", "pathak", 243456.17565, "7149987432", "BMXPC9845D");
Employee e3=new Employee("pratik", "joshi", 253456.27565, "9149987432", "CMXPC9845C");
Employee e4=new Employee("ram", "patil", 263456.47565, "9949987432", "DMXPC9845B");
Employee e5=new Employee("ajay", "patil", 273456.67565, "7749987432", "EMXPC9845A");

map.put(e1.getEmployeeId(), e1);
map.put(e2.getEmployeeId(), e2);
map.put(e3.getEmployeeId(), e3);
map.put(e4.getEmployeeId(), e4);
map.put(e5.getEmployeeId(), e5);

}
	

public Map<Integer, Employee> getMap() {
	return map;
}

}
