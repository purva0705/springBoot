package com.atossyntel.ems.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Repository;

import com.atossyntel.ems.data.EmployeeMap;
import com.atossyntel.ems.model.Employee;

@Lazy(value=true)
@Repository("mapEmployeeDaoImpl")
public class MapEmployeeDaoImpl implements EmployeeDao {

	
	public MapEmployeeDaoImpl() {
	System.out.println("MApEmployeeDaoImpl created...");
	}
	
	@Override
	public boolean saveEmployee(Employee employee) {

		return EmployeeMap.INSTANCE.getMap().put(employee.getEmployeeId(), employee) == employee;
	}

	@Override
	public Employee findEmployee(int employeId) {
		// TODO Auto-generated method stub
		return EmployeeMap.INSTANCE.getMap().get(employeId);
	}

	@Override
	public boolean deleteEmployee(int employeeId) {
	
		if(EmployeeMap.INSTANCE.getMap().containsKey(employeeId))
		{
			EmployeeMap.INSTANCE.getMap().remove(employeeId);
			return true;
		}
			
		return false;
	
	}

	@Override
	public boolean updateEmployee(Employee employee) {
		if(EmployeeMap.INSTANCE.getMap().containsKey(employee.getEmployeeId()))
		{
			EmployeeMap.INSTANCE.getMap().put(employee.getEmployeeId(), employee);
			return true;
		}
			
		return false;
	}

	@Override
	public List<Employee> findAllEmployees() {
		
		return new ArrayList<>(EmployeeMap.INSTANCE.getMap().values());
	}

}
