package com.atossyntel.ems.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.atossyntel.ems.dao.EmployeeDao;
import com.atossyntel.ems.model.Employee;
@Lazy(value=true)
@Component
//@Service("employeeServiceImpl")
public class EmployeeServiceImpl implements EmployeeService {
	@Autowired
	@Qualifier("mapEmployeeDaoImpl")
	private EmployeeDao employeeDao;// dependency

	public EmployeeServiceImpl() {
		System.out.println("EmployeeServiceImpl created.....");
	}
	
	//constructor injection 
	public EmployeeServiceImpl(EmployeeDao employeeDao) {
		System.out.println("EmployeeServiceImpl param constructor......");
		this.employeeDao = employeeDao;
	}

	
	//setter injection
	public void setEmployeeDao(EmployeeDao employeeDao) {
		System.out.println("EmployeeServiceImpl setEmployeeDao method......");
		this.employeeDao = employeeDao;
	}

	@Override
	public boolean saveEmployee(Employee employee) {
		// TODO Auto-generated method stub
		return employeeDao.saveEmployee(employee);
	}

	@Override
	public Employee findEmployee(int employeId) {
		// TODO Auto-generated method stub
		return employeeDao.findEmployee(employeId);
	}

	@Override
	public boolean deleteEmployee(int employeeId) {
		// TODO Auto-generated method stub
		return employeeDao.deleteEmployee(employeeId);
	}

	@Override
	public boolean updateEmployee(Employee employee) {
		// TODO Auto-generated method stub
		return employeeDao.updateEmployee(employee);
	}

	@Override
	public List<Employee> findAllEmployees() {
		// TODO Auto-generated method stub
		return employeeDao.findAllEmployees();
	}

}
