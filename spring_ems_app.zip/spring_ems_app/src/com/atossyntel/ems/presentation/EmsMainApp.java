package com.atossyntel.ems.presentation;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;

import com.atossyntel.ems.model.Employee;
import com.atossyntel.ems.service.EmployeeService;
@Lazy(value=true)
@Component
//@Controller("emsMainApp")
public class EmsMainApp {

@Autowired
//dependenecy
private EmployeeService employeeService;


public EmsMainApp() {
System.out.println("EmsApp Created.....");
}

//setter injection
public void setEmployeeService(EmployeeService employeeService) {
	this.employeeService = employeeService;
	System.out.println("In EmsApp setEmployeeService  ...");

}


//constructor injection
public EmsMainApp(EmployeeService employeeService) {
	this.employeeService = employeeService;
	System.out.println("In EmsApp param constructor.....  ...");
}



public void saveEmployee(Employee employee){
	
	if(employeeService.saveEmployee(employee))
		System.out.println("Employee addedd successfully...");
	else
		System.out.println("Problem in insetion...");
	
	
	
}
public void updateEmployee(Employee employee){
	if(employeeService.updateEmployee(employee))
		System.out.println("Employee addedd successfully...");
	else
		System.out.println("Employee doesn't exist ");
	
}
public void deleteEmployee(int employeeId){

	if(employeeService.deleteEmployee(employeeId))
		System.out.println("Employee deleted successfully...");
	else
		System.out.println("Employee doesn't exist..");
	
}
public void findEmployee(int employeeId){
	Employee employee=employeeService.findEmployee(employeeId);
	if(employee!=null)
	{
		System.out.println("Employee Details\n=====================================");
	System.out.println(employee);
	}
	
	else
		System.out.println("Employee doesn't exist...");
	
	
}
public void findAllEmployees(){
	System.out.println("All employees");
	System.out.println("======================================");
	for(Employee e:employeeService.findAllEmployees())
     System.out.println(e);
	
}

@PostConstruct
public void init(){
	System.out.println("########EmsApp is going trhough initalization########");
}

@PreDestroy
public void destroy(){
	System.out.println("#######EmsApp is going trhough destruction######");
}




public static void main(String[] args) {
	ApplicationContext c=new 
			 ClassPathXmlApplicationContext("beans-autowire-anno.xml");

	System.out.println("Spring Container created.....");

	//EmsMainApp e=c.getBean(EmsMainApp.class);
	
	EmsMainApp e=(EmsMainApp)c.getBean("emsMainApp");
	EmsMainApp e1=(EmsMainApp)c.getBean("emsMainApp");
	
	System.out.println("e==e1  :"+(e==e1));
	e.findAllEmployees();
	
	((ClassPathXmlApplicationContext)c).close();
	

}


}
