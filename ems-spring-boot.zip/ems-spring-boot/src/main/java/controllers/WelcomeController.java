package controllers;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class WelcomeController {

public WelcomeController() {
System.out.println("Welcome controller created....");
}
	
@GetMapping("/welcome")
public  String hello(){
	return "welcome GET";
}	

@PostMapping("/welcome")
public  String helloPost(){
	return "welcome Post";
}	
@PutMapping("/welcome")
public  String helloPut(){
	return "welcome Put";
}	
@PatchMapping("/welcome")
public  String helloPatch(){
	return "welcome Patch";
}	
@DeleteMapping("/welcome")
public  String helloDelete(){
	return "welcome Delete";
}	
	


}
