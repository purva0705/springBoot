package com.atossyntel.ems.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.atossyntel.ems.dao.EmployeeDao;
import com.atossyntel.ems.model.Employee;
import com.atossyntel.ems.repository.EmployeeRepository;

@Service("esri")
public class EmployeeServiceRepositoryImpl implements EmployeeService {

	@Autowired
	private EmployeeRepository employeeRepository;

	public EmployeeServiceRepositoryImpl() {
		System.out.println("EmployeeServiceRepositoryImpl created.....");
	}

	@Override
	public boolean saveEmployee(Employee employee) {

		return employeeRepository.save(employee) == employee;

	}

	@Override
	public Employee findEmployee(int employeId) {

		return employeeRepository.findById(employeId).get();
	}

	@Override
	public boolean deleteEmployee(int employeeId) {

		Employee employee = employeeRepository.findById(employeeId).get();

		if (employee != null) {
			employeeRepository.delete(employee);
			return true;
		}
return false;
	}

	@Override
	public boolean updateEmployee(Employee employee) {
	return employeeRepository.save(employee)==employee;
			
	}

	@Override
	public List<Employee> findAllEmployees() {
		// TODO Auto-generated method stub
		return employeeRepository.findAll();
	}

}
