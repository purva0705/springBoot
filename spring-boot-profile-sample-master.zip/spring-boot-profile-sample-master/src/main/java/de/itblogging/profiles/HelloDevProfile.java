package de.itblogging.profiles;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

@Configuration
@Profile("dev")
public class HelloDevProfile {

    @Bean(name = "environment")
    public String getEnvironment() {
        return "dev";
    }

}
