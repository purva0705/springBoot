package de.itblogging.profiles;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class HelloDefaultProfile {

    @Bean(name = "environment")
    public String getEnvironment() {
        return "default";
    }
}
