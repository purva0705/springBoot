package com.atossyntel.ems.spring.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.atossyntel.ems.service.EmployeeService;

@Controller
public class EmsSpringController {

@Autowired
@Qualifier("employeeServiceImpl")
private EmployeeService employeeService;  //dependenecy

public EmsSpringController() {
System.out.println("EmsSpringController  Created.....");
}


@RequestMapping("/hello1")
public String hello(){
System.out.println("In EmsSpring hello method...");
	return "hello";
}


@RequestMapping("/semployees")
public ModelAndView getAllEmployees(){
System.out.println("In EmsSpring getallemployees...");
	return new ModelAndView("employeeList", "employees", employeeService.findAllEmployees());
}





}











