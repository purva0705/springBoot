package com.example.springbootemsv2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootEmsV2Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootEmsV2Application.class, args);
	}
}
