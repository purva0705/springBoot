# Spring Boot Actuator Example


- `/youtube` - returns custom actuator REST URL for monitoring
- `/health`, `trace`, `env`, `info` - predefined URLs in actuators with default implementation from Spring Boot
